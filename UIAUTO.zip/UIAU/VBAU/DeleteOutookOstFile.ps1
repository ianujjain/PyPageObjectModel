cls
$users = Get-ChildItem -Path "C:\Users" 
$users | ForEach-Object{ 
	#if(Test-Path "C:\Users\$($_.Name)\AppData\Local\Microsoft\Outlook\*.ost"){
        Write-Host "C:\Users\$($_.Name)\AppData\Local\Microsoft\Outlook\*.ost"
	    Remove-Item -Path "C:\Users\$($_.Name)\AppData\Local\Microsoft\Outlook\*.ost" -Force 
   # }
}